try{var t=localStorage.getItem("theme");(t==="light"||t==="navy")&&document.documentElement.setAttribute("data-theme",t)}catch{}
