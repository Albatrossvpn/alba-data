self.__albatrossUnlock=[{hosts:["flow.google.com"],patch:[{kind:"batchexecute",url:"/data/batchexecute",rpc:"cPZSdc",index:30,type:"boolean",orNull:!0,min:32,value:!0}]}];
