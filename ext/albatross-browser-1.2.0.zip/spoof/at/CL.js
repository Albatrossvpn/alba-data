self.__albatrossAt={tz:"America/Santiago",lat:-33.4489,lon:-70.6693};
