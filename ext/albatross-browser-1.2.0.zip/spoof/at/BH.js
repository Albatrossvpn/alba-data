self.__albatrossAt={tz:"Asia/Bahrain",lat:26.2285,lon:50.586};
