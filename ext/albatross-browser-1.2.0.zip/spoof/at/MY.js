self.__albatrossAt={tz:"Asia/Kuala_Lumpur",lat:3.139,lon:101.6869};
