self.__albatrossAt={tz:"Asia/Taipei",lat:25.033,lon:121.5654};
