self.__albatrossAt={tz:"Europe/Vilnius",lat:54.6872,lon:25.2797};
