self.__albatrossAt={tz:"Europe/Stockholm",lat:59.3293,lon:18.0686};
