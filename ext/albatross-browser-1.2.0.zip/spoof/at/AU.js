self.__albatrossAt={tz:"Australia/Sydney",lat:-33.8688,lon:151.2093};
