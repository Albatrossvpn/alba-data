self.__albatrossAt={tz:"Europe/Rome",lat:41.9028,lon:12.4964};
