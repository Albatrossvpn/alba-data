self.__albatrossAt={tz:"Asia/Seoul",lat:37.5665,lon:126.978};
