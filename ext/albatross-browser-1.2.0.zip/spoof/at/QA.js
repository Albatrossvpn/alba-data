self.__albatrossAt={tz:"Asia/Qatar",lat:25.2854,lon:51.531};
