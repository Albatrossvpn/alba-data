self.__albatrossAt={tz:"Europe/Prague",lat:50.0755,lon:14.4378};
