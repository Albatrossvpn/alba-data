self.__albatrossAt={tz:"Asia/Tokyo",lat:35.6762,lon:139.6503};
