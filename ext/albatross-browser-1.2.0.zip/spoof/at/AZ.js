self.__albatrossAt={tz:"Asia/Baku",lat:40.4093,lon:49.8671};
