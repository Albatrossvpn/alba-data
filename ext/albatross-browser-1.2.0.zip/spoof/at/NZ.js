self.__albatrossAt={tz:"Pacific/Auckland",lat:-36.8485,lon:174.7633};
