self.__albatrossAt={tz:"Asia/Muscat",lat:23.588,lon:58.3829};
