self.__albatrossAt={tz:"America/Toronto",lat:43.6532,lon:-79.3832};
