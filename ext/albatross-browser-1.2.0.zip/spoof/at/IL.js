self.__albatrossAt={tz:"Asia/Jerusalem",lat:32.0853,lon:34.7818};
