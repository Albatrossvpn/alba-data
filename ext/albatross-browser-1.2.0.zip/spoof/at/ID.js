self.__albatrossAt={tz:"Asia/Jakarta",lat:-6.2088,lon:106.8456};
