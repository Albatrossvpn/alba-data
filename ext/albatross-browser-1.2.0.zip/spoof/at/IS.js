self.__albatrossAt={tz:"Atlantic/Reykjavik",lat:64.1466,lon:-21.9426};
