self.__albatrossAt={tz:"Africa/Johannesburg",lat:-26.2041,lon:28.0473};
