self.__albatrossAt={tz:"Europe/Sarajevo",lat:43.8563,lon:18.4131};
