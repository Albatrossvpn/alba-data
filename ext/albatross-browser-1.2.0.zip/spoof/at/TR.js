self.__albatrossAt={tz:"Europe/Istanbul",lat:41.0082,lon:28.9784};
