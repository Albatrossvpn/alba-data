self.__albatrossAt={tz:"America/Mexico_City",lat:19.4326,lon:-99.1332};
