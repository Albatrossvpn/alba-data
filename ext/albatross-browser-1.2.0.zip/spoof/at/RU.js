self.__albatrossAt={tz:"Europe/Moscow",lat:55.7558,lon:37.6173};
