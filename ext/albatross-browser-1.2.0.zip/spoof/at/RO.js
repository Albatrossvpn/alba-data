self.__albatrossAt={tz:"Europe/Bucharest",lat:44.4268,lon:26.1025};
