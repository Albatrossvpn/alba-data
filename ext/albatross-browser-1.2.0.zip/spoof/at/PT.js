self.__albatrossAt={tz:"Europe/Lisbon",lat:38.7223,lon:-9.1393};
