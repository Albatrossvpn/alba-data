self.__albatrossAt={tz:"Europe/Copenhagen",lat:55.6761,lon:12.5683};
