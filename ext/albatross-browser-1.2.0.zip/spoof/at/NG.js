self.__albatrossAt={tz:"Africa/Lagos",lat:6.5244,lon:3.3792};
