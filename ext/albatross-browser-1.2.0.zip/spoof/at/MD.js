self.__albatrossAt={tz:"Europe/Chisinau",lat:47.0105,lon:28.8638};
