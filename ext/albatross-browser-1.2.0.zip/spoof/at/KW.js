self.__albatrossAt={tz:"Asia/Kuwait",lat:29.3759,lon:47.9774};
