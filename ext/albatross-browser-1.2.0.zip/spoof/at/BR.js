self.__albatrossAt={tz:"America/Sao_Paulo",lat:-23.5505,lon:-46.6333};
