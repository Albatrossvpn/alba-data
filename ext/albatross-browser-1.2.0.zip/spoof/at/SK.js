self.__albatrossAt={tz:"Europe/Bratislava",lat:48.1486,lon:17.1077};
