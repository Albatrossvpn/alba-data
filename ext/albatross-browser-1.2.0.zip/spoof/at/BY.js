self.__albatrossAt={tz:"Europe/Minsk",lat:53.9006,lon:27.559};
