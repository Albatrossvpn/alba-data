self.__albatrossAt={tz:"Asia/Singapore",lat:1.3521,lon:103.8198};
