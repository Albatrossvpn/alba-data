self.__albatrossAt={tz:"Asia/Yerevan",lat:40.1792,lon:44.4991};
