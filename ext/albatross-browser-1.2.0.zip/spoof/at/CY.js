self.__albatrossAt={tz:"Asia/Nicosia",lat:35.1856,lon:33.3823};
