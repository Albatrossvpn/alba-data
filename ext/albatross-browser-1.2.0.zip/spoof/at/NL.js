self.__albatrossAt={tz:"Europe/Amsterdam",lat:52.3676,lon:4.9041};
