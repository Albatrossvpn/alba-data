self.__albatrossAt={tz:"Europe/Kyiv",lat:50.4501,lon:30.5234};
