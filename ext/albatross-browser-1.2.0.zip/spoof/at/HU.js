self.__albatrossAt={tz:"Europe/Budapest",lat:47.4979,lon:19.0402};
