self.__albatrossAt={tz:"Europe/Vienna",lat:48.2082,lon:16.3738};
