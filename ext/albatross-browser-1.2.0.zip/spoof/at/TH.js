self.__albatrossAt={tz:"Asia/Bangkok",lat:13.7563,lon:100.5018};
