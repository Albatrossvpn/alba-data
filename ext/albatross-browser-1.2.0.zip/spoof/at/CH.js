self.__albatrossAt={tz:"Europe/Zurich",lat:47.3769,lon:8.5417};
