self.__albatrossAt={tz:"Europe/Berlin",lat:52.52,lon:13.405};
