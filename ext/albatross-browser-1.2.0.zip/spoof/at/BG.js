self.__albatrossAt={tz:"Europe/Sofia",lat:42.6977,lon:23.3219};
