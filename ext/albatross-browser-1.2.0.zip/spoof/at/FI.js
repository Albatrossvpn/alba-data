self.__albatrossAt={tz:"Europe/Helsinki",lat:60.1699,lon:24.9384};
