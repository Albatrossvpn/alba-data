self.__albatrossAt={tz:"Europe/Tirane",lat:41.3275,lon:19.8187};
