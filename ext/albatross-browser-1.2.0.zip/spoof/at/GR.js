self.__albatrossAt={tz:"Europe/Athens",lat:37.9838,lon:23.7275};
