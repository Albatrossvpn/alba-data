self.__albatrossAt={tz:"Asia/Shanghai",lat:39.9042,lon:116.4074};
