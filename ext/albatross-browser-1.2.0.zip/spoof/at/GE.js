self.__albatrossAt={tz:"Asia/Tbilisi",lat:41.7151,lon:44.8271};
