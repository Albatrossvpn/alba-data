self.__albatrossAt={tz:"Europe/Riga",lat:56.9496,lon:24.1052};
