self.__albatrossAt={tz:"America/Bogota",lat:4.711,lon:-74.0721};
