self.__albatrossAt={tz:"Europe/London",lat:51.5072,lon:-.1276};
