self.__albatrossAt={tz:"Africa/Cairo",lat:30.0444,lon:31.2357};
