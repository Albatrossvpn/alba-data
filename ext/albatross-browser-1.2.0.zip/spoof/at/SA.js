self.__albatrossAt={tz:"Asia/Riyadh",lat:24.7136,lon:46.6753};
