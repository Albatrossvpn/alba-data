self.__albatrossAt={tz:"Europe/Belgrade",lat:44.7866,lon:20.4489};
