self.__albatrossAt={tz:"Europe/Dublin",lat:53.3498,lon:-6.2603};
