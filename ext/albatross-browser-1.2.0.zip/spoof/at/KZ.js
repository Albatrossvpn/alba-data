self.__albatrossAt={tz:"Asia/Almaty",lat:43.222,lon:76.8512};
