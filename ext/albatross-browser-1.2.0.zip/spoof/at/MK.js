self.__albatrossAt={tz:"Europe/Skopje",lat:41.9981,lon:21.4254};
