self.__albatrossAt={tz:"America/Argentina/Buenos_Aires",lat:-34.6037,lon:-58.3816};
