self.__albatrossAt={tz:"Europe/Oslo",lat:59.9139,lon:10.7522};
