self.__albatrossAt={tz:"Europe/Madrid",lat:40.4168,lon:-3.7038};
