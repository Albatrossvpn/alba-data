self.__albatrossAt={tz:"Asia/Hong_Kong",lat:22.3193,lon:114.1694};
