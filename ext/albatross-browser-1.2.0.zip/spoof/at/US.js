self.__albatrossAt={tz:"America/New_York",lat:40.7128,lon:-74.006};
