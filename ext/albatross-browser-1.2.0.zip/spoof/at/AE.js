self.__albatrossAt={tz:"Asia/Dubai",lat:24.4539,lon:54.3773};
