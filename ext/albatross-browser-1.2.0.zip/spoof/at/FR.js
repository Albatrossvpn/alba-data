self.__albatrossAt={tz:"Europe/Paris",lat:48.8566,lon:2.3522};
