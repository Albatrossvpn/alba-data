self.__albatrossAt={tz:"Africa/Nairobi",lat:-1.2921,lon:36.8219};
