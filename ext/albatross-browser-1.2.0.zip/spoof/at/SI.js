self.__albatrossAt={tz:"Europe/Ljubljana",lat:46.0569,lon:14.5058};
