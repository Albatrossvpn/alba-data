self.__albatrossAt={tz:"Europe/Luxembourg",lat:49.6116,lon:6.1319};
