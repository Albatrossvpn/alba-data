self.__albatrossAt={tz:"Asia/Baghdad",lat:33.3152,lon:44.3661};
