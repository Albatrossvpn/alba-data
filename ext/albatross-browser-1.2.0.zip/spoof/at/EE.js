self.__albatrossAt={tz:"Europe/Tallinn",lat:59.437,lon:24.7536};
