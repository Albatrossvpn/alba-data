self.__albatrossAt={tz:"Asia/Ho_Chi_Minh",lat:10.8231,lon:106.6297};
