self.__albatrossAt={tz:"Europe/Warsaw",lat:52.2297,lon:21.0122};
