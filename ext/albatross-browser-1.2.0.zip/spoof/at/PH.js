self.__albatrossAt={tz:"Asia/Manila",lat:14.5995,lon:120.9842};
