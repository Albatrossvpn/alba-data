self.__albatrossAt={tz:"Europe/Brussels",lat:50.8503,lon:4.3517};
