self.__albatrossAt={tz:"Asia/Tashkent",lat:41.2995,lon:69.2401};
