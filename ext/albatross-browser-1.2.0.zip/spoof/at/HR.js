self.__albatrossAt={tz:"Europe/Zagreb",lat:45.815,lon:15.9819};
