self.__albatrossAt={tz:"Asia/Karachi",lat:24.8607,lon:67.0011};
